Iconset: Zoo Line - Welcome to Zootopia (https://www.iconfinder.com/iconsets/zoo-line-welcome-to-zootopia)
Author: Chanut is Industries (https://www.iconfinder.com/Chanut-is)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2022-01-20